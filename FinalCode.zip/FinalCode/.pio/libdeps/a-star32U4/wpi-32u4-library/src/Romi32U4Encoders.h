// Copyright Pololu Corporation.  For more information, see http://www.pololu.com/

/*! \file Romi32U4Encoders.h */

#pragma once

